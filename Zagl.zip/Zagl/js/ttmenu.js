
        // keep the dropdown open
        $('.dropdown-menu').on({
            "click": function(e) {
                e.stopPropagation();
            }
        });

        // vertical tabs;
        $(document).ready(function() {
            $("div.zaglnav-tab-menu>div.list-group>a").click(function(e) {
                e.preventDefault();
                var bg = $(this).attr('data-bg');
                $('#main-menu .dropdown-menu').css('background-image', 'linear-gradient(to right, rgba(246,248,250,1) 40%, rgba(246,248,250,0.5)), url(' + bg + ')');

                $(this).siblings('a.active').removeClass("active");
                $(this).addClass("active");
                var index = $(this).index();
                $("div.zaglnav-tab>div.zaglnav-tab-content").removeClass("active");
                $("div.zaglnav-tab>div.zaglnav-tab-content").eq(index).addClass("active");
            });
        });

        /****** New menu ********/
        $(document).mouseup(function(e) {
            var container = $("#main-menu .multi-column,#main-menu .dropdown-toggle");
            if (!container.is(e.target) && container.has(e.target).length === 0) {
                $('#main-menu .dropdown-toggle .bars').removeClass('hidden').toggleClass('show');
                $('#main-menu .dropdown-toggle .times').removeClass('show').toggleClass('hidden');

            }

            var partnerContainer = $("#secondary-menu .partner .multi-column, #secondary-menu .partner .dropdown-toggle");
            if (!partnerContainer.is(e.target) && partnerContainer.has(e.target).length === 0) {
                $('#secondary-menu .partner .dropdown-toggle .fa').removeClass('fa-angle-up').addClass('fa-angle-down');
            }

            var langContainer = $("#secondary-menu .lang .multi-column, #secondary-menu .lang .dropdown-toggle");
            if (!langContainer.is(e.target) && langContainer.has(e.target).length === 0) {
                $('#secondary-menu .lang .dropdown-toggle .fa').removeClass('fa-angle-up').addClass('fa-angle-down');
            }

            var searchContainer = $("#secondary-menu .search");
            if (!searchContainer.is(e.target) && searchContainer.has(e.target).length === 0) {
                $('#secondary-menu .search input').val('').hide(200);
                $('#secondary-menu .search .fa-search').removeClass('search-submit');
            }

            var mobileSearchContainer = $("#mobile-menu .search");
            if (!mobileSearchContainer.is(e.target) && mobileSearchContainer.has(e.target).length === 0) {
                $('#mobile-menu .search input').val('').hide(200);
                $('#mobile-menu .search .fa-search').removeClass('search-submit');
            }

        });
        $('#main-menu .dropdown-toggle').click(function() {
            $('#main-menu .dropdown-toggle .bars').removeClass('show').toggleClass('hidden');
            $('#main-menu .dropdown-toggle .times').removeClass('hidden').toggleClass('show');
        });

        // search box
        $('#secondary-menu .search .fa-search').click(function() {
            $(this).addClass('search-submit');
            $('#secondary-menu .search input').show(500);
        });

        $('#mobile-menu .search .fa-search').click(function() {
            $(this).addClass('search-submit');
            $('#mobile-menu .search input').show(500);
        });

        function cleanUp(selector){
            var search = $(selector).val();

            search = search.trim().
                replace(/<script[^>]*?>.*?<\/script>/gi, '').
                replace(/<[\/\!]*?[^<>]*?>/gi, '').
                replace(/<style[^>]*?>.*?<\/style>/gi, '').
                replace(/<![\s\S]*?--[ \t\n\r]*>/gi, '');
            return search;
        }

        function searchBing(selector) {
            search = cleanUp(selector);
            if (search != '') {
                window.location.href = "https://www.grab.com/sg/search?key=" + search;
            }
        }

        $(document).on("click", '#secondary-menu .search-submit.fa-search', function(e) {
            ga('send','event','desktop-search','click',cleanUp('#secondary-menu .search input'));
            searchBing('#secondary-menu .search input');
        });
        $(document).on("click", '#mobile-menu .search-submit.fa-search', function(e) {
            ga('send','event','mobile-search','click',cleanUp('#mobile-menu .search input'));
            searchBing('#mobile-menu .search input');
        });
        $(document).on("click", '#gr-g-search-404 .fa-search', function(e) {
            ga('send','event','404-search','click',cleanUp('#gr-g-search-key-404'));
            searchBing('#gr-g-search-key-404');
        });

        $('#secondary-menu').on('keyup', '#search-key', function(e) {
            if (e.keyCode === 13) {
                e.preventDefault();
                ga('send','event','desktop-search','click',cleanUp('#secondary-menu .search input'));
                searchBing('#secondary-menu .search input');
            }
        });

        $('#mobile-menu').on('keyup', '#mobile-search', function(e) {
            if (e.keyCode === 13) {
                e.preventDefault();
                ga('send','event','mobile-search','click',cleanUp('#mobile-menu .search input'));
                searchBing('#mobile-menu .search input');
            }
        });
        $('#gr-g-search-404').on('keyup', '#gr-g-search-key-404', function(e) {
            if (e.keyCode === 13) {
                e.preventDefault();
                ga('send','event','404-search','click',cleanUp('#gr-g-search-key-404'));
                searchBing('#gr-g-search-key-404');
            }
        });
